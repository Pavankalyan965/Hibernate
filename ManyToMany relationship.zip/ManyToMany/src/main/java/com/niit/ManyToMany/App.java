package com.niit.ManyToMany;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.niit.relationships.model.Course;
import com.niit.relationships.model.Student;

public class App 
{
    public static void main( String[] args )
    {
    	Course c=new Course();
    	c.setCid("c201");
    	c.setCname("PGP JAVA");
    	    	     	
    	 Student s=new Student();
         s.setSid("s102");
         s.setSname("karthik");
         s.setMarks(70);
         s.getCourse().add(c);
         
         
         c.getStudent().add(s);
    	
        
        Configuration cfg=new Configuration().configure().addAnnotatedClass(Student.class).addAnnotatedClass(Course.class);
    	SessionFactory sf=cfg.buildSessionFactory();
    	
    	Session session= sf.openSession();
    	Transaction tx=session.beginTransaction();
    	
    	session.save(c);
    	session.save(s);
    	
    	tx.commit();
    	
    	
        

    }
}
