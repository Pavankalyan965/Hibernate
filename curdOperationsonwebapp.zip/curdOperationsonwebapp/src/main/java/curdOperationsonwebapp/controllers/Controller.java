package curdOperationsonwebapp.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import dao.Dao;
import model.Student;
@WebServlet(urlPatterns = {"/reqreg","/reqviewallusers","/reqsearch","/reqdelete","/requpdatedetails","/requpdate"})
public class Controller extends HttpServlet
{
	public void doPost(HttpServletRequest req,HttpServletResponse res) throws IOException, ServletException
	{
		PrintWriter out=res.getWriter();
		String path=req.getServletPath();
		if(path.equals("/reqreg"))
		{
			boolean b=false;
			Student s=new Student();
			s.setSid(req.getParameter("t1"));
			s.setName(req.getParameter("t2"));
			s.setEmail(req.getParameter("t3"));
			s.setMarks(req.getParameter("t4"));
			s.setCity(req.getParameter("t5"));
			new Dao().insert(s);
			if(b)
			{
               RequestDispatcher rd=req.getRequestDispatcher("index.jsp");
               rd.include(req, res);
               out.print("Record inserted successfully");
               
			}
		
		}
		else if(path.equals("/reqsearch"))
		{
			Student s=new Student();
			s.setSid(req.getParameter("sid"));
			s=new Dao().search(s);
			req.setAttribute("student",s);
			RequestDispatcher rd=req.getRequestDispatcher("viewStudent.jsp");
			rd.forward(req, res);
			
		}
	}
	public void doGet(HttpServletRequest req,HttpServletResponse res) throws IOException, ServletException
	{
		PrintWriter out=res.getWriter();
		String path=req.getServletPath();
		if(path.equals("/reqviewallusers"))
		{
			ArrayList<Student> al=new ArrayList<Student>();
			al=(ArrayList<Student>)new Dao().viewAllStudents();
			req.setAttribute("students", al);
			RequestDispatcher rd=req.getRequestDispatcher("viewStudents.jsp");
            rd.forward(req, res);
	
		}
		else if(path.equals("/reqdelete"))
		{
			Student s=new Student();
			s.setSid(req.getParameter("t1"));
			boolean b=new Dao().delete(s);
			if(b)
			{
				
				RequestDispatcher rd=req.getRequestDispatcher("reqviewallusers");
				rd.forward(req, res);
			}
		}
		else if(path.equals("/requpdate"))
		{
			Student s=new Student();
			s.setSid(req.getParameter("t1"));
			
			s=new Dao().getDataToUpdate(s);
			try
			{
				if(s!=null)
				{
					out.print("<body bgcolor=DACBC9><center><br><br><form action=requpdatedetails><table border=3>");
					out.print("<tr><td>Sid :</td><td> <input type=text name=t1 value="+s.getSid()+"></td></tr>");
					out.print("<tr><td>Name :</td><td> <input type=text name=t2 value="+s.getName()+"></td></tr>");
					out.print("<tr><td>Email :</td><td> <input type=text name=t3 value="+s.getEmail()+"></td></tr>");
					out.print("<tr><td>Marks :</td><td> <input type=text  name=t4 value="+s.getMarks()+"></td></tr>");
					out.print("<tr><td>City :</td><td> <input type=text  name=t5 value="+s.getCity()+"></td></tr>");
					out.print("<tr><td><input type=submit value=Update></td><td> <input type=reset value=Clear></td></tr></table></form>");
				}
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
		}
	
		else if(path.equals("/requpdatedetails"))
		{
			Student s=new Student();
			s.setSid(req.getParameter("t1"));
			s.setName(req.getParameter("t2"));
			s.setEmail(req.getParameter("t3"));
			s.setMarks(req.getParameter("t4"));
			s.setCity(req.getParameter("t5"));
			boolean b=new Dao().updateDetails(s);
			if(b)
			{
			//	req.setAttribute("msg", "Details updated successfully click here to <a href=index.jsp>Go back</a>");
				RequestDispatcher rd=req.getRequestDispatcher("/viewStudent.jsp");
				rd.forward(req, res);
			}
			else
			{
				req.setAttribute("msg", "Details not updated");
				RequestDispatcher rd=req.getRequestDispatcher("update?t1="+s.getSid()+"");
				rd.forward(req, res);
			}
		}
	}
	
}
