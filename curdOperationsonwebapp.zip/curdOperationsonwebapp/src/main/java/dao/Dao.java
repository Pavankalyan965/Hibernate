package dao;

import java.util.ArrayList;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import model.Student;

public class Dao 
{
	SessionFactory sf=null;
	public Dao()
	{
		Configuration cfg=new Configuration().configure().addAnnotatedClass(Student.class);
		sf= cfg.buildSessionFactory();
	}
	public void insert(Student s)
	{
		Session session=sf.openSession();
		Transaction tx=session.beginTransaction();
		session.save(s);
		tx.commit();
		sf.close();
	}
	public ArrayList<Student> viewAllStudents()
	{
		ArrayList<Student> al=new ArrayList<Student>();
		Session session=sf.openSession();
		al=(ArrayList<Student>)session.createQuery("from Student").list();
		return al;
	}
	
	public Student search(Student s)
	{
		
		Session session=sf.openSession();
		s=(Student)session.get(Student.class, s.getSid());
		return s;
	}
	public boolean delete(Student s)
	{
		boolean b=false;
		Session session=sf.openSession();
		Transaction t=session.beginTransaction();
		session.delete(s);
		t.commit();
		b=true;
		return b;
	}
	public Student getDataToUpdate(Student s) 
	{
		Session ses=sf.openSession();
		s=(Student)ses.get(Student.class, s.getSid());
		ses.close();
		return s;
	}

	public boolean updateDetails(Student s)
	{
		boolean b=false;
		Session session=sf.openSession();
		Transaction t=session.beginTransaction();
		session.update(s);
		b=true;
		t.commit();
		session.close();
		return b;
	}
}
