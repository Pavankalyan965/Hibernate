package com.niit.hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.niit.hibernate.model.FullName;
import com.niit.hibernate.model.Student;

public class App 
{
    public static void main( String[] args )
    {
    	FullName fn=new FullName();
    	fn.setFname("raja");
    	fn.setMname("ramesh");
    	fn.setLname("reddy");
    	Student s=new Student();
    	s.setName(fn);
    	s.setMarks(87);
    	s.setCity("Hyderabad");
    	s.setEmail("rajaramesh@gmail.com");
    	s.setGender("male");
    	
    	Configuration cfg=new Configuration().configure().addAnnotatedClass(Student.class);
    	SessionFactory sf=cfg.buildSessionFactory();
    	Session session=sf.openSession();
    	Transaction t=session.beginTransaction();
    	session.save(s);
    	t.commit();
    }
}
